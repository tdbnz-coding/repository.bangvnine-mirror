# NZ News Kodi Addon

Displays full news articles from RNZ, Stuff, and ODT in Kodi.